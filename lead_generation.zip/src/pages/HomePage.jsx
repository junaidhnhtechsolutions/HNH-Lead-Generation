import TableSection from '../components/TableSection'

const HomePage = () => {
    return (
        <>
            <TableSection />
        </>
    )
}

export default HomePage
