export const basedUrl = "https://192.168.114.19:8000/";

